﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        TrackBar1 = New TrackBar()
        TextBox1 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(TrackBar1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), Image)
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Location = New Point(0, 82)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(559, 320)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Segoe UI", 18F)
        Button1.Location = New Point(436, 418)
        Button1.Name = "Button1"
        Button1.Size = New Size(311, 40)
        Button1.TabIndex = 1
        Button1.Text = "SuperMarco :DDDDDD" & vbCrLf
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TrackBar1
        ' 
        TrackBar1.Location = New Point(30, 7)
        TrackBar1.Maximum = 49
        TrackBar1.Name = "TrackBar1"
        TrackBar1.Size = New Size(717, 45)
        TrackBar1.TabIndex = 2
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Comic Sans MS", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(597, 94)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(168, 24)
        TextBox1.TabIndex = 3
        TextBox1.Text = "Code: 2783629479432"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Location = New Point(12, 436)
        Label1.Name = "Label1"
        Label1.Size = New Size(372, 15)
        Label1.TabIndex = 4
        Label1.Text = "https://1drv.ms/f/s!Ar-BvHMQXBwGgo58RWA6ItNZ7ggl9Q?e=473lXz"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Comic Sans MS", 72F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(565, 190)
        Label2.Name = "Label2"
        Label2.Size = New Size(236, 135)
        Label2.TabIndex = 5
        Label2.Text = "nice"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(788, 470)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(TextBox1)
        Controls.Add(TrackBar1)
        Controls.Add(Button1)
        Controls.Add(PictureBox1)
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "Form1"
        Text = "SuperMarco /s"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(TrackBar1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label

End Class
