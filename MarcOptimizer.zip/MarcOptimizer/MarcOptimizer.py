import getpass
from win10toast import ToastNotifier
import time
import os
import shutil

home_directory = os.path.expanduser('~')  # Ottieni la directory home dell'utente
print("Loading...")
time.sleep(10)

utente = getpass.getuser()
print("Lavorando sulla directory: " + utente)

# Pulizia della cartella AppData
folder = r'C:\Users\{0}\AppData\Local'.format(utente)  # Usa la variabile utente correttamente
for filename in os.listdir(folder):
    file_path = os.path.join(folder, filename)
    try:
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)
    except Exception as e:
        print(f"Errore durante la pulizia della cartella {folder}: {e}")

# Pulizia della cartella Windows\Temp
folder2 = r'C:\Windows\Temp'
for filename in os.listdir(folder2):
    file_path = os.path.join(folder2, filename)
    try:
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)
    except Exception as e:
        print(f"Errore durante la pulizia della cartella {folder2}: {e}")

# Rimozione della cartella Windows.old
path = r"C:\Windows.old"
if os.path.exists(path):
    try:
        shutil.rmtree(path)  # Usa shutil.rmtree per rimuovere directory non vuote
        print(f"Cartella {path} rimossa con successo!")
    except Exception as e:
        print(f"Errore durante la rimozione della cartella {path}: {e}")
else:
    print(f"La cartella {path} non esiste.")

# Notifica di completamento
n = ToastNotifier()
n.show_toast("MarcOptimizer", "Divertiti con il tuo nuovo computer ottimizzato!", duration=3)

print("Done :DDDD")
time.sleep(1)

# Chiusura della finestra
print("Chiusura della finestra tra 4 secondi...")
time.sleep(4)
quit()  # Usa quit() con le parentesi per terminare il programma
